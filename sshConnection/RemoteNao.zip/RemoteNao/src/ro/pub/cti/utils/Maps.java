package ro.pub.cti.utils;

import java.util.HashMap;
import java.util.Map;

import ro.pub.cti.remotenao.R;

public class Maps {
	public static final Map<String, String> bodyComponents;
	static {
		bodyComponents = new HashMap<String, String>();
		bodyComponents.put("Left Leg", "LLeg");
		bodyComponents.put("Right Leg", "RLeg");
		bodyComponents.put("Left Arm", "LArm");
		bodyComponents.put("Right Arm", "RArm");
	}
	
	public static final Map<Integer, String> moveCommand;
	static {
		moveCommand = new HashMap<Integer, String>();
		moveCommand.put(R.id.moveBackwardButton, "/moveBackward");
		moveCommand.put(R.id.moveForwardButton, "/moveForward");
		moveCommand.put(R.id.moveLeftButton, "/moveLeft");
		moveCommand.put(R.id.moveRightButton, "/moveRight");
		moveCommand.put(R.id.turnLeftButton, "/turnLeft");
		moveCommand.put(R.id.turnRightButton, "/turnRight");
	}
}
