package ro.pub.cti.utils;


// Can be Move or Command
public interface Task {

}
