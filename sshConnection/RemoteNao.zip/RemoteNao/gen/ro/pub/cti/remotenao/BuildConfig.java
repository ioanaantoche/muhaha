/** Automatically generated file. DO NOT MODIFY */
package ro.pub.cti.remotenao;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}